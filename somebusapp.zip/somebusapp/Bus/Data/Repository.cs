﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using Microsoft.EntityFrameworkCore;

namespace Bus.Data
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly string _filePath;
        private List<T> _entities;

        public Repository(DbContext context, string filePath)
        {
            Context = context;
            DbSet = Context.Set<T>();
            _filePath = filePath;

            LoadDataFromFile();
        }

        public DbContext Context { get; }
        public DbSet<T> DbSet { get; }

        public void Add(T entity)
        {
            _entities.Add(entity);
        }

        public void AddRange(IEnumerable<T> entities)
        {
            _entities.AddRange(entities);
        }

        public IQueryable<T> Query()
        {
            return _entities.AsQueryable();
        }

        public void Remove(T entity)
        {
            _entities.Remove(entity);
        }

        public void SaveChanges()
        {
            SaveDataToFile();
        }

        public void Update(T entity)
        {
            DbSet.Update(entity);
        }

        private void LoadDataFromFile()
        {
            if (File.Exists(_filePath))
            {
                using (var fileStream = new FileStream(_filePath, FileMode.Open))
                {
                    var serializer = new XmlSerializer(typeof(List<T>));
                    _entities = (List<T>)serializer.Deserialize(fileStream);
                }
            }
            else
            {
                _entities = new List<T>();
            }
        }

        private void SaveDataToFile()
        {
            using (var fileStream = new FileStream(_filePath, FileMode.Create))
            {
                var serializer = new XmlSerializer(typeof(List<T>));
                serializer.Serialize(fileStream, _entities);
            }
        }
    }
}
