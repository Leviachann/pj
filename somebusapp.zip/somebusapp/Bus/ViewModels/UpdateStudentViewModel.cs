﻿using Bus.Commands;
using Bus.Models;
using Bus.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Bus.ViewModels
{
    class UpdateStudentViewModel : BaseViewModel
    {

        public ICommand NavigateBackCommand { get; set; }

        public ICommand UpdateStudentCommand { get; set; }

        public SchoolBusContext context { get; set; }

        public Student TempStudent { get; set; }



        private string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set
            {
                _firstName = value;
                OnPropertChanged("FirstName");
            }
        }


        private string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set
            {
                _lastName = value;
                OnPropertChanged("LastName");
            }
        }


        private string _homeAddress;

        public string HomeAddress
        {
            get { return _homeAddress; }
            set
            {
                _homeAddress = value;
                OnPropertChanged("HomeAddress");
            }
        }


        private string _otherAddress;

        public string OtherAddress
        {
            get { return _otherAddress; }
            set
            {
                _otherAddress = value;
                OnPropertChanged("OtherAddress");
            }
        }




        public UpdateStudentViewModel(NavigationStore navigation, Student st)
        {
            context = new SchoolBusContext();
            NavigateBackCommand = new UpdateViewCommand<StudentViewModel>(navigation, () => new StudentViewModel(navigation));
            UpdateStudentCommand = new RelayCommand(UpdateStudent);
            TempStudent = st;


            FirstName = TempStudent.FirstName;
            LastName = TempStudent.LastName;
            HomeAddress = TempStudent.Home;
            OtherAddress = TempStudent.OtherAddress;

        }


        public void UpdateStudent(Object obj)
        {
            TempStudent.FirstName = FirstName;
            TempStudent.LastName = LastName;
            TempStudent.Home = HomeAddress;
            TempStudent.OtherAddress = OtherAddress;

            context.Update(TempStudent);

            context.SaveChanges();

            NavigateBackCommand.Execute(obj);
        }

    }
}
