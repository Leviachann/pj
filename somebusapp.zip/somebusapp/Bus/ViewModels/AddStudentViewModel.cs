﻿using Bus.Commands;
using Bus.Models;
using Bus.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Bus.ViewModels
{
    class AddStudentViewModel : BaseViewModel
    {

        public ICommand NavigateBackCommand { get; set; }

        public ICommand AddStudentCommand { get; set; }



        private string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set
            {
                _firstName = value;
                OnPropertChanged("FirstName");
            }
        }


        private string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set
            {
                _lastName = value;
                OnPropertChanged("LastName");
            }
        }


        private string _homeAddress;

        public string HomeAddress
        {
            get { return _homeAddress; }
            set
            {
                _homeAddress = value;
                OnPropertChanged("HomeAddress");
            }
        }


        private string _otherAddress;

        public string OtherAddress
        {
            get { return _otherAddress; }
            set
            {
                _otherAddress = value;
                OnPropertChanged("OtherAddress");
            }
        }







        public AddStudentViewModel(NavigationStore navigation)
        {
            AddStudentCommand = new RelayCommand(AddStudent);
            NavigateBackCommand = new UpdateViewCommand<StudentViewModel>(navigation, () => new StudentViewModel(navigation));

        }


        public void AddStudent(Object obj)
        {
            try
            {
                var temp = new Student() { FirstName = FirstName, LastName = LastName, Home = HomeAddress, OtherAddress = OtherAddress };
                context.Add(temp);
                context.SaveChanges();
                NavigateBackCommand.Execute(obj);
            }
            catch (Exception)
            {
                MessageBox.Show("You need to enter Parent/Class");
            }
        }

    }
}
