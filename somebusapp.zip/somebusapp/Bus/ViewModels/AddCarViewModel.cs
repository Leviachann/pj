﻿using Bus.Commands;
using Bus.Models;
using Bus.Stores;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;

namespace Bus.ViewModels
{
    class AddCarViewModel : BaseViewModel
    {
        private readonly NavigationStore _navigation;
        private readonly SchoolBusContext _context = new SchoolBusContext();

        public ICommand NavigateBackCommand { get; }

        public ICommand AddCarCommand { get; }

        public Car Car { get; } = new Car();

        public string DriverName { get; set; }

        public List<string> DriverNames { get; set; }

        public AddCarViewModel(NavigationStore navigation)
        {
            _navigation = navigation;
            AddCarCommand = new RelayCommand(AddCar);
            NavigateBackCommand = new UpdateViewCommand<CarViewModel>(_navigation, () => new CarViewModel(_navigation));

            DriverNames = _context.Drivers
                .Where(d => d.Car == null)
                .Select(d => d.FirstName)
                .ToList();
        }

        private void AddCar(object obj)
        {
            Car.Driver = _context.Drivers.FirstOrDefault(d => d.FirstName == DriverName);
            _context.Add(Car);
            _context.SaveChanges();
            NavigateBackCommand.Execute(obj);
        }
    }
}
