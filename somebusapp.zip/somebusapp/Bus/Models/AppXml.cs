﻿using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace Bus.Models
{
    public class SchoolBusData
    {

        public List<Student> Students { get; set; }
        public List<Ride> Rides { get; set; }
        public List<Car> Cars { get; set; }
        public List<Driver> Drivers { get; set; }
        public List<RideStudent> RideStudents { get; set; }
        public List<Attendance> Attendances { get; set; }
        public List<Group> Groups { get; set; }

        public void SaveDataToXml(string filePath)
        {
            using (var writer = new StreamWriter(filePath))
            {
                var serializer = new XmlSerializer(typeof(SchoolBusData));
                serializer.Serialize(writer, this);
            }
        }

        public static SchoolBusData LoadDataFromXml(string filePath)
        {
            using (var reader = new StreamReader(filePath))
            {
                var serializer = new XmlSerializer(typeof(SchoolBusData));
                return (SchoolBusData)serializer.Deserialize(reader);
            }
        }
    }
}
