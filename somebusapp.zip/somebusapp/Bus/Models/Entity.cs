﻿namespace Bus.Models
{
    public abstract class Entity
    {
        public int Id { get; set; }

        public static void MapProperties<T>(T entityFrom, T entityTo) where T : Entity
        {
            foreach (var from in typeof(T).GetProperties())
            {
                foreach (var to in typeof(T).GetProperties())
                {
                    if (from.Name == to.Name && from.Name != "Id")
                    {
                        if (from.GetValue(entityFrom) != null)
                            to.SetValue(entityTo, from.GetValue(entityFrom));
                    }
                }
            }
        }
    }
}
