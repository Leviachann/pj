﻿using System.Collections.Generic;

namespace Bus.Models
{
    public class Group : Entity
    {
        public string Title { get; set; }
        public virtual ICollection<Student> Students { get; set; } = new List<Student>();
    }
}

