﻿using Bus.Stores;
using Bus.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Bus.Commands
{
    class UpdateViewCommand<TViewModel> : ICommand where TViewModel : BaseViewModel
    {
        private NavigationStore _navigationStore;

        private readonly Func<TViewModel> _createViewModel;

        public UpdateViewCommand(NavigationStore navigationStore, Func<TViewModel> createViewModel)
        {
            _navigationStore = navigationStore;
            _createViewModel = createViewModel;
        }


        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            _navigationStore.SelectedViewModel = _createViewModel();
        }
    }
}
